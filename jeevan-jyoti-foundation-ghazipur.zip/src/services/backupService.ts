/**
 * Backup Service
 * Exports and compiles complete Firestore database backups for donations, volunteers, and certificates.
 */

import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import { db, isMockFirebase } from '../lib/firebase';
import { logAdminActivity } from './adminService';

export interface FirestoreBackupSummary {
  totalDonations: number;
  totalDonationAmountInr: number;
  totalVolunteers: number;
  totalTasksCompletedByVolunteers: number;
  totalIssuedCertificates: number;
  donationsWithPanCount: number;
}

export interface FirestoreBackupPayload {
  metadata: {
    exportDate: string;
    organization: string;
    exportedBy: {
      name: string;
      uid: string;
      role: string;
    };
    version: string;
    summary: FirestoreBackupSummary;
    checksumSha256?: string;
  };
  collections: {
    donations: any[];
    volunteers: any[];
    certificates: any[];
    appContent?: any;
  };
}

/**
 * Compiles real-time donations, volunteers, and certificates from Firestore or local fallback
 */
export async function compileDonationsAndVolunteersBackup(adminInfo?: {
  name: string;
  uid: string;
  role: string;
}): Promise<FirestoreBackupPayload> {
  const donations: any[] = [];
  const volunteers: any[] = [];
  const certificates: any[] = [];
  let appContent: any = null;

  let totalDonationAmount = 0;
  let donationsWithPan = 0;
  let totalTasksCompleted = 0;

  try {
    if (!isMockFirebase && db) {
      // 1. Fetch Donations
      try {
        const donationsSnap = await getDocs(collection(db, 'donations'));
        donationsSnap.forEach((docSnap) => {
          const data = { id: docSnap.id, ...docSnap.data() } as any;
          donations.push(data);
          const amt = Number(data.amount || data.donationAmount || 0);
          if (!isNaN(amt)) totalDonationAmount += amt;
          if (data.panNumber || data.donorPan) donationsWithPan++;
        });
      } catch (err) {
        console.warn('Error fetching donations for backup:', err);
      }

      // 2. Fetch Volunteers
      try {
        const volunteersSnap = await getDocs(collection(db, 'volunteers'));
        volunteersSnap.forEach((docSnap) => {
          const data = { id: docSnap.id, ...docSnap.data() } as any;
          volunteers.push(data);
          const tasks = Number(data.completedTasks || data.tasksCount || 0);
          if (!isNaN(tasks)) totalTasksCompleted += tasks;
        });
      } catch (err) {
        console.warn('Error fetching volunteers for backup:', err);
      }

      // 3. Fetch Certificates / Verified Registry
      try {
        const certsSnap = await getDocs(collection(db, 'certificates'));
        certsSnap.forEach((docSnap) => {
          certificates.push({ id: docSnap.id, ...docSnap.data() });
        });
      } catch (err) {
        console.warn('Error fetching certificates for backup:', err);
      }

      // 4. Fetch Home Content
      try {
        const homeDoc = await getDoc(doc(db, 'appContent', 'home'));
        if (homeDoc.exists()) {
          appContent = homeDoc.data();
        }
      } catch (err) {
        console.warn('Error fetching home content for backup:', err);
      }
    }
  } catch (error) {
    console.warn('Firestore backup read exception, using fallback caches:', error);
  }

  // Fallback to localStorage records if Firestore was empty or offline
  if (donations.length === 0 && typeof window !== 'undefined') {
    try {
      const cachedDonations = localStorage.getItem('jjf_donations_cache');
      if (cachedDonations) {
        const parsed = JSON.parse(cachedDonations);
        if (Array.isArray(parsed)) {
          parsed.forEach((d: any) => {
            donations.push(d);
            const amt = Number(d.amount || 0);
            if (!isNaN(amt)) totalDonationAmount += amt;
            if (d.panNumber) donationsWithPan++;
          });
        }
      }
    } catch {}
  }

  if (volunteers.length === 0 && typeof window !== 'undefined') {
    try {
      const cachedVolunteers = localStorage.getItem('jjf_volunteers_cache');
      if (cachedVolunteers) {
        const parsed = JSON.parse(cachedVolunteers);
        if (Array.isArray(parsed)) {
          parsed.forEach((v: any) => {
            volunteers.push(v);
            const tasks = Number(v.completedTasks || 0);
            if (!isNaN(tasks)) totalTasksCompleted += tasks;
          });
        }
      }
    } catch {}
  }

  let checksumSha256 = '';
  try {
    const rawData = JSON.stringify({ donations, volunteers, certificates, totalDonationAmount });
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const msgBuffer = new TextEncoder().encode(rawData);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      checksumSha256 = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    } else {
      checksumSha256 = 'jjf_' + Math.abs(rawData.split('').reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) | 0, 0)).toString(16);
    }
  } catch {
    checksumSha256 = 'sha256_' + Date.now().toString(16);
  }

  const payload: FirestoreBackupPayload = {
    metadata: {
      exportDate: new Date().toISOString(),
      organization: 'Jeevan Jyoti Foundation Ghazipur (UP/2018/0207700)',
      exportedBy: {
        name: adminInfo?.name || 'व्यवस्थापक',
        uid: adminInfo?.uid || 'admin',
        role: adminInfo?.role || 'Admin'
      },
      version: 'v2.0.0-PROD',
      summary: {
        totalDonations: donations.length,
        totalDonationAmountInr: totalDonationAmount,
        totalVolunteers: volunteers.length,
        totalTasksCompletedByVolunteers: totalTasksCompleted,
        totalIssuedCertificates: certificates.length,
        donationsWithPanCount: donationsWithPan
      },
      checksumSha256
    },
    collections: {
      donations,
      volunteers,
      certificates,
      appContent
    }
  };

  return payload;
}

/**
 * Triggers client-side browser JSON file download
 */
export function downloadBackupJsonFile(payload: FirestoreBackupPayload, customFileName?: string): string {
  const dateStr = new Date().toISOString().split('T')[0];
  const fileName = customFileName || `JJF_Database_Backup_${dateStr}.json`;
  const jsonContent = JSON.stringify(payload, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });

  if (typeof window !== 'undefined') {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  return fileName;
}

/**
 * Executes a manual backup, triggers download, updates metadata, and records audit trail
 */
export async function executeManualDatabaseBackup(adminInfo: {
  name: string;
  uid: string;
  role: string;
}): Promise<{
  success: boolean;
  fileName: string;
  payload: FirestoreBackupPayload;
  summary: {
    totalDonations: number;
    totalVolunteers: number;
    totalCertificates: number;
  };
}> {
  const payload = await compileDonationsAndVolunteersBackup(adminInfo);
  const fileName = downloadBackupJsonFile(payload);

  // Store backup metadata locally for quick status display
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('jjf_last_backup_timestamp', new Date().toISOString());
      localStorage.setItem(
        'jjf_last_backup_meta',
        JSON.stringify({
          fileName,
          totalDonations: payload.metadata.summary.totalDonations,
          totalVolunteers: payload.metadata.summary.totalVolunteers,
          totalCertificates: payload.metadata.summary.totalIssuedCertificates
        })
      );
    } catch {}
  }

  // Audit log
  logAdminActivity({
    adminUid: adminInfo.uid,
    adminName: adminInfo.name,
    action: 'DATA_BACKUP_EXPORT',
    details: `डेटाबेस का पूर्ण JSON बैकअप डाउनलोड किया गया (${fileName})`
  }).catch(() => {});

  return {
    success: true,
    fileName,
    payload,
    summary: {
      totalDonations: payload.metadata.summary.totalDonations,
      totalVolunteers: payload.metadata.summary.totalVolunteers,
      totalCertificates: payload.metadata.summary.totalIssuedCertificates
    }
  };
}
